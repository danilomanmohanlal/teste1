package pt.scml.fin.li_ips;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiIpsApplicationTests {


}
