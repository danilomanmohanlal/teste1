package pt.scml.fin.li_ips.tasklet;


import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import pt.scml.fin.li_ips.JobParameters;
import pt.scml.fin.li_ips.utils.LIInvoicingParameterValidator;

public class PrepareFinancialCycle implements Tasklet {

    private final LIInvoicingParameterValidator validator;
    private final JobParameters jobParameters;

    public PrepareFinancialCycle(LIInvoicingParameterValidator validator,  JobParameters jobParameters) {
        this.validator = validator;
        this.jobParameters = jobParameters;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
            throws Exception {

        System.out.println();



        return RepeatStatus.FINISHED;
    }
}
